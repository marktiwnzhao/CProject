//
// Created by Misaka on 2021/12/10.
//

#include <stdio.h>
#include <windows.h>
#include <conio.h>

#include "Settings.c"

//开始界面
void Start (int * high, FILE * sc_b) {
    char ch_score[100];
    int score = 0;
    //得到最高分
    while (fgets(ch_score, sizeof(ch_score), sc_b)) {
        score = strtod(ch_score, NULL);
        if (*high < score) {
            *high = score;
        }
    }
    system("cls");  //清屏
    //标题居中
    for (int i = 0; i <= WIDTH/2 - 3; i ++) {
        printf(" ");
    }
    printf("Snake\n"
           "Highest Score: %d\n"
           "'b' to begin! Good luck!\n", *high);
    while (1) {
        if (kbhit() && getch() == 'b') {
            break;
        }
    }
}

//初始化
void Initialize (int * dire, int * len, int * bool, int * pau, unsigned * inv, int map[HEIGHT][WIDTH]) {
    //初始化地图
    for (int i = 0; i < HEIGHT; i ++) {
        for (int r = 0; r < WIDTH; r ++) {
            map[i][r] = 0;
        }
    }
    //初始化状态
    *bool = 0;
    *pau = 0;
    //初始化方向
    *dire = 1;
    //初始化长度
    *len = 3;
    //初始化速度
    *inv = 500;
    //初始化蛇在中央
    map[HEIGHT/2 + 1][WIDTH/2] = 3;
    map[HEIGHT/2][WIDTH/2] = 2;
    map[HEIGHT/2 - 1][WIDTH/2] = 1;
    //初始化果子在左上角
    map[3][3] = -1;
}

//响应键盘
void Input (int * dire, int * bool, int * pau) {
    int command = 0;
    if (kbhit()) {
        switch (getch()) {
            case 'a': command = 2; break; //表示向左
            case 'w': command = 1; break; //表示向上
            case 's': command = -1; break; //表示向下
            case 'd': command = -2; break; //表示向右
            case 'p': *pau = 1; break; //表示暂停
            case 'q': *bool = 1; break; //表示退出
            default: break;
        }
    }
    //检测是否反向
    if ((*dire + command)*command != 0) {
        *dire = command;
    }
}

//移动
void Move (const int dire, int * len, int * bool, int map[HEIGHT][WIDTH]) {
    int new_i = 0;
    int new_r = 0;
    for (int i = 0; i < HEIGHT; i ++) {
        for (int r = 0; r < WIDTH; r ++) {
            //蛇头
            if (map[i][r] == 1) {
                map[i][r] ++;
                switch (dire) {
                    case 2: new_i = i; new_r = r - 1; break;
                    case 1: new_i = i - 1; new_r = r; break;
                    case -1: new_i = i + 1; new_r = r; break;
                    case -2: new_i = i; new_r = r + 1; break;
                    default: break;
                }
            }
            //蛇身
            else if (map[i][r] > 1 && map[i][r] < *len) {
                map[i][r] ++;
            }
            //蛇尾
            else if (map[i][r] == *len) {
                map[i][r] = 0;
            }
        }
    }
    //如果吃到食物
    if (map[new_i][new_r] == -1) {
        *len = *len + 1;            //长度增加
        map[new_i][new_r] = 1;      //新的头部
        //随机生成新的果子
        while (1) {
            int fruit_i = rand() % HEIGHT;
            int fruit_r = rand() % WIDTH;
            if (map[fruit_i][fruit_r] == 0) {
                map[fruit_i][fruit_r] = -1;
                break;
            }
        }
    }
    //如果撞墙或撞到自己
    else if (new_i < 0 || new_r < 0 || new_i >= HEIGHT || new_r >= WIDTH
        || map[new_i][new_r] > 0) {
        *bool = 1;      //将end设为1
    }
    //正常移动
    else {
        map[new_i][new_r] = 1;
    }
}

//刷新屏幕
void Draw (int len , int high, int map[HEIGHT][WIDTH]) {
    system("cls"); //清除屏幕

    for (int i = 0; i <= WIDTH/2 - 3; i ++) {
        printf(" ");
    }
    printf("Snake\n"
           "Highest Score: %d\n"
           "Score: %d\n"
           "Pause: p  Quit: q\n", high, len - 3); //标题

    for (int i = 0; i <= WIDTH + 1; i ++) {
        if (i == 0 || i == WIDTH + 1) {
            printf("+");
        } else {
            printf("-"); //上边框
        }
    }
    printf("\n");

    for (int i = 0; i < HEIGHT; i++)
    {
        for (int r = 0; r < WIDTH; r++)
        {
            if (r == 0) {
                printf("|"); //左边框
            }
            if (map[i][r] == 1) {
                printf("@"); //输出蛇头
            } else if (map[i][r] > 1) {
                printf("*"); //输出蛇身
            } else if (map[i][r] == -1) {
                printf("$"); //输出果子
            } else {
                printf(" ");
            }
            if (r == WIDTH - 1) {
                printf("|"); //右边框
            }
        }
        printf("\n");
    }

    for (int i = 0; i <= WIDTH + 1; i++)
    {
        if (i == 0 || i == WIDTH + 1) {
            printf("+");
        } else {
            printf("-"); //下边框
        }
    }
    printf("\n");
}

//逐渐加速
void SpeedUp (unsigned * inv, int len) {
    if (*inv > 100) {
        *inv = 500 - len * 50;
    }
}

//检测退出
void End (int len, int * high, int * leave, FILE * sc_b) {
    system("cls");
    fprintf(sc_b, "%d\n", len - 3);
    if (len - 3 > *high) {
        printf("New Best!\n");
        *high = len - 3;
    }
    printf("Game Over!\n"
           "Highest Score: %d\n"
           "Your Score: %d\n"
           "'q' to quit or 'r' to restart\n", *high, len - 3);
    while (1) {
        if (kbhit()) {
            if (getch() == 'q') {
                *leave = 1;
                break;
            } else if (getch() == 'r') {
                break;
            }
        }
    }
}

//暂停
void Pause (int * pau, int * bool) {
    printf("Pause\n"
           "'b' to begin or 'q' to quit\n");
    while (1) {
        if (kbhit()) {
            if (getch() == 'b') {
                * pau = 0;
                break;
            } else if (getch() == 'q') {
                * bool = 1;
                break;
            }
        }
    }
}
