//
// Created by Misaka on 2021/12/10.
//

#include "Function.c"
#include "Settings.c"

int main () {
    int map[HEIGHT][WIDTH] = {0};       //地图 0为空,-1为果子，n为第n节
    int direction = 0;               //方向 1,2,-1,-2 代表上，左，下，右
    int length = 0;                  //蛇长
    unsigned interval = 500;        //初始间隔为500
    int end = 0;                     //是否结束
    int pause = 0;                   //是否暂停
    int leave = 0;                   //是否离开
    FILE *scoreboard = fopen("Scoreboard.txt", "r+");  //计分板
    if (scoreboard == NULL) {
        printf("Scoreboard Not Found!\n");
        return 0;
    }
    int highest_s = 0;

    while (1) {
        //主程序
        Initialize(&direction, &length, &end, &pause, &interval, map);

        Start(&highest_s, scoreboard);

        while (1) {
            Input(&direction, &end, &pause);

            if (pause) {
                Pause(&pause, &end);
            }

            Move(direction, &length, &end, map);

            if (end) {
                break;
            }

            Draw(length, highest_s, map);

            SpeedUp(&interval, length);

            Sleep(interval);
        }

        End(length, &highest_s, &leave, scoreboard);

        if (leave) {
            break;
        }
    }

    fclose(scoreboard); //关闭计分板

    return 0;
}